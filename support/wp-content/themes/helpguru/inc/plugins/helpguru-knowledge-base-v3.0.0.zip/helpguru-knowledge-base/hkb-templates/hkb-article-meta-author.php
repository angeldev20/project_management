<li class="hkb-meta__author">
    <?php the_author(); ?>
</li>